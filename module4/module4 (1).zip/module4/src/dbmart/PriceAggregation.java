package dbmart;

public class PriceAggregation {

}
